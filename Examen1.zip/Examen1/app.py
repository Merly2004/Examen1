from flask import Flask, request, render_template_string
from tensorflow.keras.models import load_model
import numpy as np
from PIL import Image

app = Flask(__name__)
model = load_model("modelo_mnist.h5")

# Página principal
@app.route('/')
def home():
    return render_template_string('''
        <html>
        <head>
            <title> MNIST Predictor</title>
            <style>
                body {
                    font-family: 'Inter', sans-serif;
                    background: linear-gradient(135deg, #e0f2fe, #f8fafc);
                    margin: 0;
                    height: 100vh;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                }
                .card {
                    background: white;
                    box-shadow: 0 6px 20px rgba(0,0,0,0.1);
                    border-radius: 20px;
                    padding: 40px;
                    width: 380px;
                    text-align: center;
                    transition: transform 0.3s ease;
                }
                .card:hover {
                    transform: translateY(-5px);
                }
                h2 {
                    color: #1f4e79;
                    margin-bottom: 10px;
                }
                p {
                    color: #475569;
                    font-size: 15px;
                }
                input[type=file] {
                    margin: 20px 0;
                    padding: 10px;
                    border: 1px solid #cbd5e1;
                    border-radius: 10px;
                    width: 100%;
                    cursor: pointer;
                }
                input[type=submit] {
                    background: #1f4e79;
                    color: white;
                    border: none;
                    padding: 12px 24px;
                    border-radius: 12px;
                    font-size: 16px;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                input[type=submit]:hover {
                    background: #2563eb;
                    transform: scale(1.05);
                }
                .result {
                    margin-top: 25px;
                    font-size: 20px;
                    color: #16a34a;
                    font-weight: bold;
                }
            </style>
        </head>
        <body>
            <div class="card">
                <h2> Predicción de Dígitos MNIST</h2>
                <p>Sube una imagen (28x28 píxeles o un número escrito a mano)</p>
                <form action="/predict" method="post" enctype="multipart/form-data">
                    <input type="file" name="file" accept="image/*" required>
                    <br>
                    <input type="submit" value="🔍 Predecir">
                </form>
            </div>
        </body>
        </html>
    ''')

# Ruta de predicción
@app.route('/predict', methods=['POST'])
def predict():
    file = request.files['file']

    # Procesar la imagen
    image = Image.open(file).convert('L')
    image = image.resize((28, 28))
    image = np.array(image).astype('float32') / 255.0
    image = image.reshape(1, 28, 28, 1)

    # Predicción
    prediccion = np.argmax(model.predict(image))

    # Mostrar resultado con estilo
    return render_template_string('''
        <html>
        <head>
            <title> MNIST Predictor</title>
            <style>
                body {
                    font-family: 'Inter', sans-serif;
                    background: linear-gradient(135deg, #e0f2fe, #f8fafc);
                    margin: 0;
                    height: 100vh;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                }
                .card {
                    background: white;
                    box-shadow: 0 6px 20px rgba(0,0,0,0.1);
                    border-radius: 20px;
                    padding: 40px;
                    width: 380px;
                    text-align: center;
                }
                h2 {
                    color: #1f4e79;
                }
                .result {
                    font-size: 30px;
                    color: #16a34a;
                    font-weight: bold;
                    margin-top: 15px;
                }
                a {
                    display: inline-block;
                    margin-top: 20px;
                    text-decoration: none;
                    color: white;
                    background: #1f4e79;
                    padding: 10px 20px;
                    border-radius: 12px;
                    transition: all 0.3s ease;
                }
                a:hover {
                    background: #2563eb;
                    transform: scale(1.05);
                }
            </style>
        </head>
        <body>
            <div class="card">
                <h2> Predicción completada</h2>
                <p>El número predicho por el modelo es:</p>
                <div class="result">{{ prediccion }}</div>
                <a href="/">🔙 Volver</a>
            </div>
        </body>
        </html>
    ''', prediccion=int(prediccion))

if __name__ == '__main__':
    app.run(debug=True)
